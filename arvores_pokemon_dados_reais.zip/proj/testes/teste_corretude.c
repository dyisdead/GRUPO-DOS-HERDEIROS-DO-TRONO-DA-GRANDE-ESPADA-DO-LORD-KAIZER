/*
 * Testes de corretude: inserção, busca, remoção, percursos e os 7 casos
 * extremos listados na seção 3.3 do README.
 *
 * Compilar (veja o Makefile) e rodar:
 *     ./teste_corretude
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <assert.h>

#include "../src/registro.h"
#include "../src/avl.h"
#include "../src/rubro_negra.h"
#include "../src/dataset.h"

/* ---------------- geração de registros sintéticos ---------------- */

static Registro registro_aleatorio(long id, long total_stats, const char *nome) {
    Registro r;
    r.id = id;
    if (nome != NULL) {
        snprintf(r.nome, TAM_NOME, "%s", nome);
    } else {
        snprintf(r.nome, TAM_NOME, "Criatura%d", rand() % 50);
    }
    snprintf(r.tipo, TAM_TIPO, "%s", (rand() % 2) ? "pokemon" : "humano");
    snprintf(r.genero, TAM_GENERO, "%s", (rand() % 2) ? "macho" : "femea");
    r.shiny = (rand() % 100) < 5;
    snprintf(r.ataques[0], TAM_ATAQUE, "A1");
    snprintf(r.ataques[1], TAM_ATAQUE, "A2");
    snprintf(r.ataques[2], TAM_ATAQUE, "A3");
    snprintf(r.ataques[3], TAM_ATAQUE, "A4");
    r.ivs = 1 + rand() % 100;
    r.total_stats = (total_stats >= 0) ? total_stats : (100 + rand() % 500);
    return r;
}

/* ---------------- Caso 1: árvore vazia ---------------- */
static void teste_arvore_vazia(void) {
    ArvoreAVL avl; avl_inicializar(&avl);
    Registro chave = registro_aleatorio(1, 100, "X");
    assert(avl_buscar(&avl, &chave) == NULL);
    assert(avl_remover(&avl, &chave) == false);
    avl_destruir(&avl);

    ArvoreRN rn; rn_inicializar(&rn);
    assert(rn_buscar(&rn, &chave) == NULL);
    assert(rn_remover(&rn, &chave) == false);
    rn_destruir(&rn);

    printf("OK - caso 1 (arvore vazia)\n");
}

/* ---------------- Caso 2: unico elemento ---------------- */
static void teste_unico_elemento(void) {
    Registro r = registro_aleatorio(1, -1, NULL);

    ArvoreAVL avl; avl_inicializar(&avl);
    avl_inserir(&avl, r);
    assert(avl_buscar(&avl, &r) != NULL);
    assert(avl_validar(&avl));
    assert(avl_remover(&avl, &r) == true);
    assert(avl_altura_total(&avl) == 0);
    avl_destruir(&avl);

    ArvoreRN rn; rn_inicializar(&rn);
    rn_inserir(&rn, r);
    assert(rn_buscar(&rn, &r) != NULL);
    assert(rn_validar(&rn));
    assert(rn_remover(&rn, &r) == true);
    assert(rn_altura_total(&rn) == 0);
    rn_destruir(&rn);

    printf("OK - caso 2 (unico elemento)\n");
}

/* ---------------- Caso 3: mesmo total_stats (e mesmo nome) ---------------- */
static void teste_mesmo_total_stats(void) {
    const int n = 10;
    Registro regs[10];
    for (int i = 0; i < n; i++) {
        regs[i] = registro_aleatorio(i + 1, 300, "Pikachu");
    }

    ArvoreAVL avl; avl_inicializar(&avl);
    for (int i = 0; i < n; i++) avl_inserir(&avl, regs[i]);
    assert(avl_validar(&avl));
    for (int i = 0; i < n; i++) assert(avl_buscar(&avl, &regs[i]) != NULL);
    Registro saida[10];
    assert(avl_em_ordem(&avl, saida) == n);
    avl_destruir(&avl);

    ArvoreRN rn; rn_inicializar(&rn);
    for (int i = 0; i < n; i++) rn_inserir(&rn, regs[i]);
    assert(rn_validar(&rn));
    for (int i = 0; i < n; i++) assert(rn_buscar(&rn, &regs[i]) != NULL);
    assert(rn_em_ordem(&rn, saida) == n);
    rn_destruir(&rn);

    printf("OK - caso 3 (mesmo total_stats / mesmo nome)\n");
}

/* ---------------- Casos 4 e 5: ordem crescente/decrescente ---------------- */
static void teste_ordem_monotona(void) {
    const int n = 2000;

    for (int ordem = 0; ordem < 2; ordem++) {  /* 0 = crescente, 1 = decrescente */
        ArvoreAVL avl; avl_inicializar(&avl);
        ArvoreRN rn; rn_inicializar(&rn);

        for (int i = 0; i < n; i++) {
            long total = ordem == 0 ? i : (n - 1 - i);
            char nome[32];
            snprintf(nome, sizeof(nome), "C%ld", total);
            Registro r = registro_aleatorio(i + 1, total, nome);
            avl_inserir(&avl, r);
            rn_inserir(&rn, r);
        }

        assert(avl_validar(&avl));
        assert(rn_validar(&rn));

        double limite_avl = 1.44 * (log((double)(n + 1)) / log(2.0)) + 2;
        double limite_rn = 2.0 * (log((double)(n + 1)) / log(2.0)) + 2;
        assert(avl_altura_total(&avl) <= limite_avl);
        assert(rn_altura_total(&rn) <= limite_rn);

        avl_destruir(&avl);
        rn_destruir(&rn);
    }

    printf("OK - casos 4 e 5 (ordem crescente/decrescente nao degenera)\n");
}

/* ---------------- Caso 6: volume maior ---------------- */
static void teste_volume(int n) {
    ArvoreAVL avl; avl_inicializar(&avl);
    ArvoreRN rn; rn_inicializar(&rn);

    Registro *inseridos = (Registro *) malloc(sizeof(Registro) * n);

    for (int i = 0; i < n; i++) {
        Registro r = registro_aleatorio(i + 1, -1, NULL);
        inseridos[i] = r;
        avl_inserir(&avl, r);
        rn_inserir(&rn, r);
    }

    assert(avl_validar(&avl));
    assert(rn_validar(&rn));

    Registro *saida = (Registro *) malloc(sizeof(Registro) * n);
    assert(avl_em_ordem(&avl, saida) == n);
    assert(rn_em_ordem(&rn, saida) == n);

    /* busca de 200 elementos existentes, escolhidos aleatoriamente */
    for (int k = 0; k < 200; k++) {
        int i = rand() % n;
        assert(avl_buscar(&avl, &inseridos[i]) != NULL);
        assert(rn_buscar(&rn, &inseridos[i]) != NULL);
    }

    free(inseridos);
    free(saida);
    avl_destruir(&avl);
    rn_destruir(&rn);

    printf("OK - caso 6 (volume de %d registros)\n", n);
}

/* ---------------- Caso 7: remover tudo ate esvaziar ---------------- */
static void teste_remover_tudo(void) {
    const int n = 3000;
    Registro *regs = (Registro *) malloc(sizeof(Registro) * n);
    for (int i = 0; i < n; i++) regs[i] = registro_aleatorio(i + 1, -1, NULL);

    /* embaralha a ordem de remoção (Fisher-Yates) */
    for (int i = n - 1; i > 0; i--) {
        int j = rand() % (i + 1);
        Registro tmp = regs[i]; regs[i] = regs[j]; regs[j] = tmp;
    }

    ArvoreAVL avl; avl_inicializar(&avl);
    ArvoreRN rn; rn_inicializar(&rn);
    for (int i = 0; i < n; i++) { avl_inserir(&avl, regs[i]); rn_inserir(&rn, regs[i]); }

    for (int i = 0; i < n; i++) {
        assert(avl_remover(&avl, &regs[i]) == true);
        assert(avl_validar(&avl));
        assert(rn_remover(&rn, &regs[i]) == true);
        assert(rn_validar(&rn));
    }

    assert(avl_altura_total(&avl) == 0);
    assert(rn_altura_total(&rn) == 0);

    free(regs);
    avl_destruir(&avl);
    rn_destruir(&rn);

    printf("OK - caso 7 (remover tudo ate esvaziar)\n");
}

/* ---------------- em_ordem() deve respeitar a chave composta ---------------- */
static void teste_percurso_ordenado(void) {
    const int n = 2000;
    ArvoreAVL avl; avl_inicializar(&avl);
    ArvoreRN rn; rn_inicializar(&rn);
    for (int i = 0; i < n; i++) {
        Registro r = registro_aleatorio(i + 1, -1, NULL);
        avl_inserir(&avl, r);
        rn_inserir(&rn, r);
    }

    Registro *saida = (Registro *) malloc(sizeof(Registro) * n);
    int total = avl_em_ordem(&avl, saida);
    for (int i = 1; i < total; i++) {
        assert(comparar_registro(&saida[i - 1], &saida[i]) < 0);
    }

    total = rn_em_ordem(&rn, saida);
    for (int i = 1; i < total; i++) {
        assert(comparar_registro(&saida[i - 1], &saida[i]) < 0);
    }

    free(saida);
    avl_destruir(&avl);
    rn_destruir(&rn);

    printf("OK - em_ordem() respeita a chave composta\n");
}

/* ---------------- dados REAIS (PokeAPI) -- dataset/pokemon_dataset.csv ---------------- */
static void teste_dataset_real(void) {
    const char *caminho = dataset_localizar();
    if (caminho == NULL) {
        printf("AVISO - teste com dados reais PULADO: dataset nao encontrado.\n"
               "        Gere com: python dataset/gerar_dataset.py\n");
        return;
    }

    const long n_max = 100000;
    Registro *regs = NULL;
    long n = dataset_carregar(caminho, n_max, &regs);
    assert(n > 0);

    /* sanidade dos dados lidos do CSV */
    for (long i = 0; i < n; i++) {
        assert(regs[i].id == i + 1);
        assert(regs[i].nome[0] != '\0');
        assert(strcmp(regs[i].tipo, "pokemon") == 0 || strcmp(regs[i].tipo, "humano") == 0);
        assert(regs[i].ivs >= 1 && regs[i].ivs <= 100);
        assert(regs[i].total_stats > 0);
        assert(regs[i].ataques[0][0] != '\0');
    }

    ArvoreAVL avl; avl_inicializar(&avl);
    ArvoreRN rn; rn_inicializar(&rn);
    for (long i = 0; i < n; i++) { avl_inserir(&avl, regs[i]); rn_inserir(&rn, regs[i]); }
    assert(avl_validar(&avl));
    assert(rn_validar(&rn));

    /* em-ordem: n registros, estritamente crescentes pela chave (total_stats, nome, id) */
    Registro *saida = (Registro *) malloc(sizeof(Registro) * (size_t) n);
    assert(avl_em_ordem(&avl, saida) == n);
    for (long i = 1; i < n; i++) assert(comparar_registro(&saida[i - 1], &saida[i]) < 0);
    assert(rn_em_ordem(&rn, saida) == n);
    for (long i = 1; i < n; i++) assert(comparar_registro(&saida[i - 1], &saida[i]) < 0);

    /* todos os registros reais sao encontrados e voltam com o mesmo conteudo */
    for (long i = 0; i < n; i++) {
        const Registro *a = avl_buscar(&avl, &regs[i]);
        const Registro *b = rn_buscar(&rn, &regs[i]);
        assert(a != NULL && b != NULL);
        assert(a->id == regs[i].id && b->id == regs[i].id);
        assert(strcmp(a->nome, regs[i].nome) == 0 && strcmp(b->nome, regs[i].nome) == 0);
    }

    /* remocao em 10 lotes de 1% (registros espalhados), validando apos CADA lote */
    long removidos = 0;
    for (int lote = 0; lote < 10; lote++) {
        for (long i = lote; i < n; i += 100) {
            assert(avl_remover(&avl, &regs[i]) == true);
            assert(rn_remover(&rn, &regs[i]) == true);
            removidos++;
        }
        assert(avl_validar(&avl));
        assert(rn_validar(&rn));
    }
    for (long i = 0; i < n; i++) {
        bool removido = (i % 100) < 10;
        assert((avl_buscar(&avl, &regs[i]) != NULL) == !removido);
        assert((rn_buscar(&rn, &regs[i]) != NULL) == !removido);
    }
    assert(avl_em_ordem(&avl, saida) == n - removidos);
    assert(rn_em_ordem(&rn, saida) == n - removidos);

    printf("OK - dados reais da PokeAPI (%ld registros de %s)\n", n, caminho);
    printf("     altura apos carga: AVL=%d  RN=%d | removidos %ld e arvores ainda validas\n",
           avl_altura_total(&avl), rn_altura_total(&rn), removidos);

    free(saida);
    free(regs);
    avl_destruir(&avl);
    rn_destruir(&rn);
}

int main(void) {
    srand(42);

    teste_arvore_vazia();
    teste_unico_elemento();
    teste_mesmo_total_stats();
    teste_ordem_monotona();
    teste_volume(50000);
    teste_remover_tudo();
    teste_percurso_ordenado();
    teste_dataset_real();

    printf("\nTodos os testes de corretude passaram.\n");
    return 0;
}

/*
 * Testes de desempenho (secao 3.2 / 3.2.1 do README), versao C.
 *
 * Para cada tamanho de entrada, e para cada ordem (aleatoria / crescente):
 *   - descarta 1 execucao de aquecimento
 *   - roda 5 repeticoes
 *   - mede tempo de insercao, tempo medio de busca (1000 buscas, metade
 *     existentes / metade nao) e tempo de remocao de 10% em lote
 *   - registra rotacoes/recoloracoes e altura final
 *   - valida os invariantes de cada arvore apos a carga e apos as remocoes
 *
 * Dados: registros REAIS do dataset (dataset/pokemon_dataset.csv, gerado por
 * dataset/gerar_dataset.py a partir da PokeAPI). Para cada tamanho n usa-se os
 * n primeiros registros do arquivo (ordem aleatoria de total_stats); na ordem
 * "crescente" esses mesmos n registros sao ordenados por total_stats antes da
 * insercao (pior caso teorico para uma BST simples).
 *
 * Resultado: um CSV em /resultados com media e desvio padrao de cada
 * metrica -- no MESMO formato do resultados_desempenho.csv da versao
 * Python, entao o script gerar_graficos.py funciona nos dois.
 *
 * Uso:
 *     ./teste_desempenho                  # roda os tamanhos padrao
 *     ./teste_desempenho 1000 10000       # roda so esses tamanhos (teste rapido)
 */

#define _POSIX_C_SOURCE 199309L

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>

#include "../src/registro.h"
#include "../src/avl.h"
#include "../src/rubro_negra.h"
#include "../src/dataset.h"

#define REPETICOES 5

static const long TAMANHOS_PADRAO[] = {1000, 10000, 100000, 300000, 500000};
static const int NUM_TAMANHOS_PADRAO = 5;

/* ---------------- utilitarios de tempo ---------------- */

static double agora_segundos(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double) ts.tv_sec + (double) ts.tv_nsec / 1e9;
}

/* ---------------- selecao de dados (dataset real) ---------------- */

static int comparar_para_qsort(const void *a, const void *b) {
    return comparar_registro((const Registro *) a, (const Registro *) b);
}

/* Copia os n primeiros registros do dataset; se 'crescente', ordena por chave composta. */
static Registro *selecionar_registros(const Registro *base, long n, int crescente) {
    srand((unsigned int) n);   /* mantem sorteios (chaves de busca, remocao) reproduziveis */
    Registro *regs = (Registro *) malloc(sizeof(Registro) * (size_t) n);
    memcpy(regs, base, sizeof(Registro) * (size_t) n);
    if (crescente) {
        qsort(regs, (size_t) n, sizeof(Registro), comparar_para_qsort);
    }
    return regs;
}

/* embaralha um array de indices 0..n-1 (Fisher-Yates) */
static void embaralhar_indices(int *indices, int n) {
    for (int i = n - 1; i > 0; i--) {
        int j = rand() % (i + 1);
        int tmp = indices[i]; indices[i] = indices[j]; indices[j] = tmp;
    }
}

/* ---------------- resultado de uma execucao ---------------- */

typedef struct {
    double t_insercao;
    double t_busca_media;
    double t_remocao;
    int altura;
    long rotacoes;
    long recoloracoes;
    int invariante_apos_insercao;
    int invariante_apos_remocao;
} ResultadoExecucao;

/* monta as 1000 chaves de busca (500 existentes + 500 inexistentes), embaralhadas */
static Registro *montar_chaves_busca(Registro *registros, long n) {
    const int total = 1000;
    Registro *chaves = (Registro *) malloc(sizeof(Registro) * total);

    int *indices = (int *) malloc(sizeof(int) * (int) n);
    for (long i = 0; i < n; i++) indices[i] = (int) i;
    embaralhar_indices(indices, (int) n);

    int qtd_existentes = (n < 500) ? (int) n : 500;
    for (int k = 0; k < qtd_existentes; k++) {
        chaves[k] = registros[indices[k]];
    }
    for (int k = qtd_existentes; k < total; k++) {
        Registro r;
        memset(&r, 0, sizeof(r));
        r.id = -(k + 1);
        snprintf(r.nome, TAM_NOME, "NaoExiste");
        r.total_stats = -(1 + rand() % 1000);
        chaves[k] = r;
    }
    free(indices);

    /* embaralha as 1000 chaves (mistura existentes e inexistentes) */
    for (int i = total - 1; i > 0; i--) {
        int j = rand() % (i + 1);
        Registro tmp = chaves[i]; chaves[i] = chaves[j]; chaves[j] = tmp;
    }
    return chaves;
}

static ResultadoExecucao rodar_execucao_avl(Registro *registros, long n) {
    ResultadoExecucao res;
    memset(&res, 0, sizeof(res));

    ArvoreAVL avl;
    avl_inicializar(&avl);

    double t0 = agora_segundos();
    for (long i = 0; i < n; i++) avl_inserir(&avl, registros[i]);
    res.t_insercao = agora_segundos() - t0;
    res.invariante_apos_insercao = avl_validar(&avl);

    Registro *chaves_busca = montar_chaves_busca(registros, n);
    t0 = agora_segundos();
    for (int k = 0; k < 1000; k++) avl_buscar(&avl, &chaves_busca[k]);
    res.t_busca_media = (agora_segundos() - t0) / 1000.0;
    free(chaves_busca);

    int qtd_remover = (int) (n / 10);
    if (qtd_remover < 1) qtd_remover = 1;
    int *indices = (int *) malloc(sizeof(int) * (int) n);
    for (long i = 0; i < n; i++) indices[i] = (int) i;
    embaralhar_indices(indices, (int) n);

    t0 = agora_segundos();
    for (int k = 0; k < qtd_remover; k++) avl_remover(&avl, &registros[indices[k]]);
    res.t_remocao = agora_segundos() - t0;
    free(indices);

    res.invariante_apos_remocao = avl_validar(&avl);
    res.altura = avl_altura_total(&avl);
    res.rotacoes = avl.rotacoes;
    res.recoloracoes = 0;

    avl_destruir(&avl);
    return res;
}

static ResultadoExecucao rodar_execucao_rn(Registro *registros, long n) {
    ResultadoExecucao res;
    memset(&res, 0, sizeof(res));

    ArvoreRN rn;
    rn_inicializar(&rn);

    double t0 = agora_segundos();
    for (long i = 0; i < n; i++) rn_inserir(&rn, registros[i]);
    res.t_insercao = agora_segundos() - t0;
    res.invariante_apos_insercao = rn_validar(&rn);

    Registro *chaves_busca = montar_chaves_busca(registros, n);
    t0 = agora_segundos();
    for (int k = 0; k < 1000; k++) rn_buscar(&rn, &chaves_busca[k]);
    res.t_busca_media = (agora_segundos() - t0) / 1000.0;
    free(chaves_busca);

    int qtd_remover = (int) (n / 10);
    if (qtd_remover < 1) qtd_remover = 1;
    int *indices = (int *) malloc(sizeof(int) * (int) n);
    for (long i = 0; i < n; i++) indices[i] = (int) i;
    embaralhar_indices(indices, (int) n);

    t0 = agora_segundos();
    for (int k = 0; k < qtd_remover; k++) rn_remover(&rn, &registros[indices[k]]);
    res.t_remocao = agora_segundos() - t0;
    free(indices);

    res.invariante_apos_remocao = rn_validar(&rn);
    res.altura = rn_altura_total(&rn);
    res.rotacoes = rn.rotacoes;
    res.recoloracoes = rn.recoloracoes;

    rn_destruir(&rn);
    return res;
}

/* ---------------- media e desvio padrao ---------------- */

static void media_e_desvio(const double *valores, int n, double *media_out, double *desvio_out) {
    double soma = 0;
    for (int i = 0; i < n; i++) soma += valores[i];
    double media = soma / n;

    double soma_quad = 0;
    for (int i = 0; i < n; i++) soma_quad += (valores[i] - media) * (valores[i] - media);
    double desvio = (n > 1) ? sqrt(soma_quad / (n - 1)) : 0.0;

    *media_out = media;
    *desvio_out = desvio;
}

/* ---------------- bateria completa ---------------- */

static void escrever_linha_csv(FILE *f, const char *arvore, const char *ordem,
                                long n, const char *metrica, double media, double desvio) {
    fprintf(f, "%s,%s,%ld,%s,%.10g,%.10g\n", arvore, ordem, n, metrica, media, desvio);
}

static void rodar_bateria(const long *tamanhos, int num_tamanhos) {
    /* carrega o dataset real uma unica vez (so a leitura do arquivo fica fora da cronometragem) */
    const char *caminho_dataset = dataset_localizar();
    if (caminho_dataset == NULL) {
        fprintf(stderr, "Erro: dataset nao encontrado (dataset/pokemon_dataset.csv).\n"
                        "Gere com:  python dataset/gerar_dataset.py\n");
        return;
    }
    long maior = 0;
    for (int i = 0; i < num_tamanhos; i++) if (tamanhos[i] > maior) maior = tamanhos[i];
    Registro *dataset = NULL;
    long total_dataset = dataset_carregar(caminho_dataset, maior, &dataset);
    if (total_dataset <= 0) {
        fprintf(stderr, "Erro: nao foi possivel ler registros de %s\n", caminho_dataset);
        free(dataset);
        return;
    }
    printf("Dataset: %s (%ld registros carregados)\n\n", caminho_dataset, total_dataset);

    /* tenta nessa ordem: rodando da raiz do projeto (make/VS Code "run"),
     * rodando de dentro de /testes (cd testes && ../teste_desempenho),
     * e por ultimo a pasta atual, se nenhuma das anteriores existir. */
    const char *candidatos[] = {
        "resultados/resultados_desempenho.csv",
        "../resultados/resultados_desempenho.csv",
        "resultados_desempenho.csv",
    };
    const char *caminho_csv = NULL;
    FILE *f = NULL;
    for (int i = 0; i < 3 && f == NULL; i++) {
        f = fopen(candidatos[i], "w");
        caminho_csv = candidatos[i];
    }
    if (f == NULL) {
        fprintf(stderr, "Erro: nao foi possivel criar o arquivo de resultados. "
                        "Crie a pasta 'resultados' na raiz do projeto e tente de novo.\n");
        return;
    }
    fprintf(f, "arvore,ordem,n,metrica,media,desvio_padrao\n");

    const char *arvores[2] = {"AVL", "RubroNegra"};
    const char *ordens[2] = {"aleatoria", "crescente"};

    for (int ia = 0; ia < 2; ia++) {
        for (int io = 0; io < 2; io++) {
            int crescente = (io == 1);
            for (int it = 0; it < num_tamanhos; it++) {
                long n = tamanhos[it];
                if (n > total_dataset) {
                    printf("%-11s | ordem=%-10s | n=%7ld | PULADO (dataset so tem %ld registros)\n",
                           arvores[ia], ordens[io], n, total_dataset);
                    continue;
                }
                Registro *registros = selecionar_registros(dataset, n, crescente);

                ResultadoExecucao execucoes[REPETICOES];

                /* aquecimento (descartado) */
                if (ia == 0) { rodar_execucao_avl(registros, n); }
                else { rodar_execucao_rn(registros, n); }

                for (int rep = 0; rep < REPETICOES; rep++) {
                    execucoes[rep] = (ia == 0) ? rodar_execucao_avl(registros, n)
                                                : rodar_execucao_rn(registros, n);
                }

                double vals[REPETICOES], media, desvio;
                int invariantes_ok = 1;
                for (int rep = 0; rep < REPETICOES; rep++) {
                    if (!execucoes[rep].invariante_apos_insercao ||
                        !execucoes[rep].invariante_apos_remocao) {
                        invariantes_ok = 0;
                    }
                }

                for (int rep = 0; rep < REPETICOES; rep++) vals[rep] = execucoes[rep].t_insercao;
                media_e_desvio(vals, REPETICOES, &media, &desvio);
                escrever_linha_csv(f, arvores[ia], ordens[io], n, "t_insercao", media, desvio);

                for (int rep = 0; rep < REPETICOES; rep++) vals[rep] = execucoes[rep].t_busca_media;
                media_e_desvio(vals, REPETICOES, &media, &desvio);
                escrever_linha_csv(f, arvores[ia], ordens[io], n, "t_busca_media", media, desvio);

                for (int rep = 0; rep < REPETICOES; rep++) vals[rep] = execucoes[rep].t_remocao;
                media_e_desvio(vals, REPETICOES, &media, &desvio);
                escrever_linha_csv(f, arvores[ia], ordens[io], n, "t_remocao", media, desvio);

                for (int rep = 0; rep < REPETICOES; rep++) vals[rep] = execucoes[rep].altura;
                media_e_desvio(vals, REPETICOES, &media, &desvio);
                escrever_linha_csv(f, arvores[ia], ordens[io], n, "altura", media, desvio);

                for (int rep = 0; rep < REPETICOES; rep++) vals[rep] = (double) execucoes[rep].rotacoes;
                media_e_desvio(vals, REPETICOES, &media, &desvio);
                escrever_linha_csv(f, arvores[ia], ordens[io], n, "rotacoes", media, desvio);

                for (int rep = 0; rep < REPETICOES; rep++) vals[rep] = (double) execucoes[rep].recoloracoes;
                media_e_desvio(vals, REPETICOES, &media, &desvio);
                escrever_linha_csv(f, arvores[ia], ordens[io], n, "recoloracoes", media, desvio);

                printf("%-11s | ordem=%-10s | n=%7ld | invariantes_ok=%s\n",
                       arvores[ia], ordens[io], n, invariantes_ok ? "true" : "false");

                free(registros);
            }
        }
    }

    fclose(f);
    free(dataset);
    printf("\nResultados salvos em %s\n", caminho_csv);
}

int main(int argc, char **argv) {
    if (argc > 1) {
        int num = argc - 1;
        long *tamanhos = (long *) malloc(sizeof(long) * num);
        for (int i = 0; i < num; i++) tamanhos[i] = atol(argv[i + 1]);
        rodar_bateria(tamanhos, num);
        free(tamanhos);
    } else {
        rodar_bateria(TAMANHOS_PADRAO, NUM_TAMANHOS_PADRAO);
    }
    return 0;
}

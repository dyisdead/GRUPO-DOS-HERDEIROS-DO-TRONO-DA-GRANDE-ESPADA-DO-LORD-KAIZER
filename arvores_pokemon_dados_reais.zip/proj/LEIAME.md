# PokéTree: AVL vs Rubro-Negra (C)

```
/src         código-fonte (avl, rubro_negra, registro, dataset)
/dataset     base_especies.csv, pokemon_dataset.csv e gerar_dataset.py
/testes      teste_corretude.c e teste_desempenho.c
/resultados  CSV gerado pelo teste de desempenho
```

## Dados
Os registros vêm de dados reais da PokéAPI (espécies, variantes/formas, stats base e golpes).
Cada registro é uma instância sorteada sobre essas espécies (id único, gênero, shiny, IVs e 4 golpes)
ou um personagem humano (tabela fixa de stats base). `total_stats = soma dos 6 stats base + ivs * 0,5 por stat`.

Regerar o dataset (opcional, o CSV já vem pronto):
```
python dataset/gerar_dataset.py            # 500.000 registros
python dataset/gerar_dataset.py -n 300000  # outro volume
```

## Compilar e rodar (na raiz do projeto)
Com `make`: `make testes` e `make desempenho`.

Sem `make` (Windows/PowerShell, use `.\nome.exe` para executar):
```
gcc -Wall -Wextra -O2 -std=c11 -o teste_corretude testes/teste_corretude.c src/registro.c src/avl.c src/rubro_negra.c src/dataset.c -lm
./teste_corretude

gcc -Wall -Wextra -O2 -std=c11 -o teste_desempenho testes/teste_desempenho.c src/registro.c src/avl.c src/rubro_negra.c src/dataset.c -lm
./teste_desempenho 1000 10000     # rápido
./teste_desempenho                # bateria completa (1k a 500k), ~30 s
```

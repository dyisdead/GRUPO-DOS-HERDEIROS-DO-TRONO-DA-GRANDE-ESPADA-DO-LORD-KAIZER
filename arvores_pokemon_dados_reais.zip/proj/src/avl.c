#include "avl.h"
#include <stdlib.h>

/* ---------------- criação/destruição de nós ---------------- */

static NoAVL *novo_no(Registro registro) {
    NoAVL *no = (NoAVL *) malloc(sizeof(NoAVL));
    no->registro = registro;
    no->esquerda = NULL;
    no->direita = NULL;
    no->altura = 1;
    return no;
}

static void destruir_rec(NoAVL *no) {
    if (no == NULL) return;
    destruir_rec(no->esquerda);
    destruir_rec(no->direita);
    free(no);
}

void avl_inicializar(ArvoreAVL *arvore) {
    arvore->raiz = NULL;
    arvore->rotacoes = 0;
    arvore->comparacoes_busca = 0;
}

void avl_destruir(ArvoreAVL *arvore) {
    destruir_rec(arvore->raiz);
    arvore->raiz = NULL;
}

/* ---------------- utilitários de altura/balanceamento ---------------- */

static int altura(NoAVL *no) {
    return no ? no->altura : 0;
}

static int maior(int a, int b) {
    return a > b ? a : b;
}

static int fator_balanceamento(NoAVL *no) {
    return no ? altura(no->esquerda) - altura(no->direita) : 0;
}

static void atualizar_altura(NoAVL *no) {
    no->altura = 1 + maior(altura(no->esquerda), altura(no->direita));
}

int avl_altura_total(const ArvoreAVL *arvore) {
    return altura(arvore->raiz);
}

/* ---------------- rotações ---------------- */

static NoAVL *rot_direita(ArvoreAVL *arvore, NoAVL *y) {
    NoAVL *x = y->esquerda;
    NoAVL *t2 = x->direita;
    x->direita = y;
    y->esquerda = t2;
    atualizar_altura(y);
    atualizar_altura(x);
    arvore->rotacoes++;
    return x;
}

static NoAVL *rot_esquerda(ArvoreAVL *arvore, NoAVL *x) {
    NoAVL *y = x->direita;
    NoAVL *t2 = y->esquerda;
    y->esquerda = x;
    x->direita = t2;
    atualizar_altura(x);
    atualizar_altura(y);
    arvore->rotacoes++;
    return y;
}

static NoAVL *rebalancear(ArvoreAVL *arvore, NoAVL *no) {
    atualizar_altura(no);
    int fb = fator_balanceamento(no);

    if (fb > 1 && fator_balanceamento(no->esquerda) >= 0) {          /* Esq-Esq */
        return rot_direita(arvore, no);
    }
    if (fb > 1 && fator_balanceamento(no->esquerda) < 0) {           /* Esq-Dir */
        no->esquerda = rot_esquerda(arvore, no->esquerda);
        return rot_direita(arvore, no);
    }
    if (fb < -1 && fator_balanceamento(no->direita) <= 0) {          /* Dir-Dir */
        return rot_esquerda(arvore, no);
    }
    if (fb < -1 && fator_balanceamento(no->direita) > 0) {           /* Dir-Esq */
        no->direita = rot_direita(arvore, no->direita);
        return rot_esquerda(arvore, no);
    }
    return no;
}

/* ---------------- inserção ---------------- */

static NoAVL *inserir_rec(ArvoreAVL *arvore, NoAVL *no, Registro registro) {
    if (no == NULL) {
        return novo_no(registro);
    }

    int cmp = comparar_registro(&registro, &no->registro);
    if (cmp < 0) {
        no->esquerda = inserir_rec(arvore, no->esquerda, registro);
    } else if (cmp > 0) {
        no->direita = inserir_rec(arvore, no->direita, registro);
    } else {
        no->registro = registro;   /* chave já existe (não deveria, id é único) */
        return no;
    }

    return rebalancear(arvore, no);
}

void avl_inserir(ArvoreAVL *arvore, Registro registro) {
    arvore->raiz = inserir_rec(arvore, arvore->raiz, registro);
}

/* ---------------- busca ---------------- */

const Registro *avl_buscar(ArvoreAVL *arvore, const Registro *chave) {
    NoAVL *no = arvore->raiz;
    while (no != NULL) {
        arvore->comparacoes_busca++;
        int cmp = comparar_registro(chave, &no->registro);
        if (cmp == 0) return &no->registro;
        no = (cmp < 0) ? no->esquerda : no->direita;
    }
    return NULL;
}

/* ---------------- remoção ---------------- */

static NoAVL *menor_no(NoAVL *no) {
    NoAVL *atual = no;
    while (atual->esquerda != NULL) atual = atual->esquerda;
    return atual;
}

static NoAVL *remover_rec(ArvoreAVL *arvore, NoAVL *no, const Registro *chave, bool *removido) {
    if (no == NULL) {
        *removido = false;
        return NULL;
    }

    int cmp = comparar_registro(chave, &no->registro);
    if (cmp < 0) {
        no->esquerda = remover_rec(arvore, no->esquerda, chave, removido);
    } else if (cmp > 0) {
        no->direita = remover_rec(arvore, no->direita, chave, removido);
    } else {
        *removido = true;
        if (no->esquerda == NULL || no->direita == NULL) {
            NoAVL *filho = no->esquerda ? no->esquerda : no->direita;
            free(no);
            return filho;
        }
        NoAVL *sucessor = menor_no(no->direita);
        no->registro = sucessor->registro;
        bool removido_interno;
        no->direita = remover_rec(arvore, no->direita, &sucessor->registro, &removido_interno);
    }

    return rebalancear(arvore, no);
}

bool avl_remover(ArvoreAVL *arvore, const Registro *chave) {
    bool removido = false;
    arvore->raiz = remover_rec(arvore, arvore->raiz, chave, &removido);
    return removido;
}

/* ---------------- percursos ---------------- */

static void pre_ordem_rec(NoAVL *no, Registro *saida, int *idx) {
    if (no == NULL) return;
    saida[(*idx)++] = no->registro;
    pre_ordem_rec(no->esquerda, saida, idx);
    pre_ordem_rec(no->direita, saida, idx);
}

static void em_ordem_rec(NoAVL *no, Registro *saida, int *idx) {
    if (no == NULL) return;
    em_ordem_rec(no->esquerda, saida, idx);
    saida[(*idx)++] = no->registro;
    em_ordem_rec(no->direita, saida, idx);
}

static void pos_ordem_rec(NoAVL *no, Registro *saida, int *idx) {
    if (no == NULL) return;
    pos_ordem_rec(no->esquerda, saida, idx);
    pos_ordem_rec(no->direita, saida, idx);
    saida[(*idx)++] = no->registro;
}

int avl_pre_ordem(const ArvoreAVL *arvore, Registro *saida) {
    int idx = 0;
    pre_ordem_rec(arvore->raiz, saida, &idx);
    return idx;
}

int avl_em_ordem(const ArvoreAVL *arvore, Registro *saida) {
    int idx = 0;
    em_ordem_rec(arvore->raiz, saida, &idx);
    return idx;
}

int avl_pos_ordem(const ArvoreAVL *arvore, Registro *saida) {
    int idx = 0;
    pos_ordem_rec(arvore->raiz, saida, &idx);
    return idx;
}

/* ---------------- validação ---------------- */

static bool validar_rec(NoAVL *no, int *alt_saida) {
    if (no == NULL) {
        *alt_saida = 0;
        return true;
    }
    int alt_e, alt_d;
    bool ok_e = validar_rec(no->esquerda, &alt_e);
    bool ok_d = validar_rec(no->direita, &alt_d);
    *alt_saida = 1 + maior(alt_e, alt_d);
    int fb = alt_e - alt_d;
    return ok_e && ok_d && fb >= -1 && fb <= 1;
}

bool avl_validar(const ArvoreAVL *arvore) {
    int alt;
    return validar_rec(arvore->raiz, &alt);
}

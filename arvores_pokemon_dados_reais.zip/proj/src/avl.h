/*
 * Árvore AVL para o dataset PokéTree.
 * Balanceamento estrito: fator de balanceamento de cada nó sempre entre -1 e 1.
 */

#ifndef AVL_H
#define AVL_H

#include <stdbool.h>
#include "registro.h"

typedef struct NoAVL {
    Registro registro;
    struct NoAVL *esquerda;
    struct NoAVL *direita;
    int altura;
} NoAVL;

typedef struct {
    NoAVL *raiz;
    long rotacoes;            /* métricas de desempenho (seção 3.2) */
    long comparacoes_busca;
} ArvoreAVL;

void avl_inicializar(ArvoreAVL *arvore);
void avl_destruir(ArvoreAVL *arvore);           /* libera todos os nós */

void avl_inserir(ArvoreAVL *arvore, Registro registro);
bool avl_remover(ArvoreAVL *arvore, const Registro *chave);
const Registro *avl_buscar(ArvoreAVL *arvore, const Registro *chave);

int  avl_altura_total(const ArvoreAVL *arvore);
bool avl_validar(const ArvoreAVL *arvore);       /* checa fator de balanceamento */

/* Percursos: preenchem 'saida' (já alocado com espaço >= n) e retornam a
 * quantidade de registros escritos. */
int avl_pre_ordem(const ArvoreAVL *arvore, Registro *saida);
int avl_em_ordem(const ArvoreAVL *arvore, Registro *saida);
int avl_pos_ordem(const ArvoreAVL *arvore, Registro *saida);

#endif /* AVL_H */

/*
 * Árvore Rubro-Negra para o dataset PokéTree.
 * Implementação clássica (CLRS) com nó sentinela NIL.
 */

#ifndef RUBRO_NEGRA_H
#define RUBRO_NEGRA_H

#include <stdbool.h>
#include "registro.h"

typedef enum { PRETO, VERMELHO } Cor;

typedef struct NoRN {
    Registro registro;
    Cor cor;
    struct NoRN *esquerda;
    struct NoRN *direita;
    struct NoRN *pai;
} NoRN;

typedef struct {
    NoRN *nil;          /* sentinela: representa todas as folhas */
    NoRN *raiz;
    long rotacoes;        /* métricas (seção 3.2) */
    long recoloracoes;
    long comparacoes_busca;
} ArvoreRN;

void rn_inicializar(ArvoreRN *arvore);
void rn_destruir(ArvoreRN *arvore);

void rn_inserir(ArvoreRN *arvore, Registro registro);
bool rn_remover(ArvoreRN *arvore, const Registro *chave);
const Registro *rn_buscar(ArvoreRN *arvore, const Registro *chave);

int  rn_altura_total(const ArvoreRN *arvore);
bool rn_validar(const ArvoreRN *arvore);     /* checa as 5 propriedades de cor */

int rn_pre_ordem(const ArvoreRN *arvore, Registro *saida);
int rn_em_ordem(const ArvoreRN *arvore, Registro *saida);
int rn_pos_ordem(const ArvoreRN *arvore, Registro *saida);

#endif /* RUBRO_NEGRA_H */

/*
 * Modelo de dado do dataset PokéTree e o comparador da chave composta.
 *
 * Chave composta (seção 1.3.2 do README):
 *     chave = (total_stats, nome, id)
 *
 * Prioridade de comparação:
 *     1) total_stats  -> critério principal
 *     2) nome         -> desempate
 *     3) id           -> desempate final (único e sequencial, nunca empata)
 */

#ifndef REGISTRO_H
#define REGISTRO_H

#include <stdbool.h>

#define TAM_NOME    64
#define TAM_TIPO    16
#define TAM_GENERO  16
#define TAM_ATAQUE  32
#define NUM_ATAQUES 4

typedef struct {
    long id;
    char nome[TAM_NOME];
    char tipo[TAM_TIPO];        /* "pokemon" ou "humano" */
    char genero[TAM_GENERO];
    bool shiny;
    char ataques[NUM_ATAQUES][TAM_ATAQUE];
    int ivs;                    /* 1 a 100 */
    long total_stats;
} Registro;

/*
 * Comparador central da chave composta (total_stats, nome, id).
 * Retorna <0 se a < b, >0 se a > b, 0 se as chaves são iguais
 * (o que só acontece se for o mesmo registro, já que id é único).
 */
int comparar_registro(const Registro *a, const Registro *b);

#endif /* REGISTRO_H */

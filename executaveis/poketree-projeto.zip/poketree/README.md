# GRUPO DOS HERDEIROS DO TRONO DA GRANDE ESPADA DO LORD KAIZER

PokéTree: AVL vs Rubro-Negra

Entregas 1 e 2 do trabalho da disciplina Estruturas de Dados II - UNICID
Prof. Cid Rodrigues de Andrade

## Integrantes do Grupo

| Nome completo | RA |
|---|---|
| Diogo Henrique Pinheiro da Silva | 43614442 |
| Pedro Henrique Segala | 43695469 |
| Marconio Soares de Sousa Junior | 43840868 |
| Bruno Oliveira Theodoro | 43023452 |
| Kauan Alba Elias | 43555829 |

---

## 1. Dataset

### 1.1 Descrição

Dataset de **500.000 Pokémon**, gerado a partir de dados reais da PokéAPI. Cada registro
representa um Pokémon individual, com espécie/variante, gênero, variante shiny, 4 ataques
e valor de IV. Formato: CSV (`dataset/pokemon_dataset.csv`, ~36 MB). O volume está dentro
da faixa exigida (10 mil a 10 milhões).

> **Mudança desde a Entrega 1:** no checkpoint o dataset também tinha personagens humanos.
> O grupo decidiu manter **só Pokémon**: os humanos não têm status base na PokéAPI e
> dependeriam de uma tabela inventada, enquanto todos os Pokémon usam dados reais.

### 1.2 Fonte

* Dados base de espécies, variantes, status base e golpes: PokéAPI (https://pokeapi.co/),
  a partir dos CSVs oficiais do repositório [PokeAPI/pokeapi](https://github.com/PokeAPI/pokeapi),
  que são os mesmos dados que a API serve. Resultado: 1.351 espécies/variantes
  (`dataset/base_especies.csv`), incluindo formas regionais e especiais (ex.: `Raticate Alola`, `Melmetal Gmax`)
* Registros individuais: gerados pelo grupo (`dataset/gerar_dataset.py`) por amostragem
  aleatória dentro do espaço de combinações possíveis, com semente fixa (o mesmo comando
  sempre gera o mesmo arquivo). Não é uma enumeração exaustiva de todas as combinações,
  que passaria de centenas de milhões

### 1.3 Estrutura dos dados

* id (int): identificador único e sequencial do registro, atribuído na geração do dataset; é o campo de desempate final da chave composta
* nome (string): nome da espécie ou variante do Pokémon
* genero (string): `macho`, `femea` ou `sem genero`, sorteado respeitando a proporção real da espécie na PokéAPI
* shiny (bool): 1% de chance
* ataques (4 strings): golpes sorteados do conjunto real de golpes que a espécie aprende
* ivs (int, 1 a 100): valor individual usado no cálculo de total_stats
* total_stats (int): ver cálculo e papel na chave composta em 1.3.1

### 1.3.1 Cálculo de total_stats

total_stats é derivado dos status base da espécie (HP, Ataque, Defesa, Ataque Especial, Defesa Especial e Velocidade, obtidos da PokéAPI) ajustados pelo IV do registro:

```
stat_final_i = status_base_i + (ivs * fator_escala)   // fator_escala = 0.5
total_stats  = soma dos 6 stat_final_i                // = base_total + 3 * ivs
```

### 1.3.2 Chave composta e comparador

A chave de inserção, busca e comparação nas árvores é composta:

```
chave = (total_stats, nome, id)
```

Comparador (ordem lexicográfica, nessa ordem de prioridade), implementado em `comparar_registro()` (`src/registro.c`):

1. **total_stats** — critério principal; é o campo que o grupo quer observar em termos de distribuição e balanceamento.
2. **nome** — desempate quando dois registros têm o mesmo total_stats.
3. **id** — desempate final; como é único e sequencial, garante que a chave composta nunca tenha empate total, mesmo entre registros com mesmo total_stats e mesmo nome (ex.: dois Pikachu shiny com os mesmos stats).

Isso significa que inserção, busca e remoção por chave deixam de ser ambíguas mesmo com total_stats tendo só cerca de mil valores possíveis (993 distintos nos 500 mil registros): o terceiro campo (id) sempre resolve o empate, e a altura da árvore passa a refletir corretamente o volume de dados inserido.

### 1.4 Justificativa da escolha

total_stats é um valor numérico com boa distribuição entre os registros, o que ajuda nos testes de balanceamento da AVL e da Rubro-Negra; nome e id complementam a chave garantindo unicidade sem distorcer essa distribuição. O volume de centenas de milhares de registros permite ver o comportamento das árvores em escala e comparar o crescimento real de tempo/altura com a complexidade teórica O(log n).

---

## 2. Estrutura(s) de Árvore Escolhida(s)

### 2.1 Estrutura(s)

* AVL (`src/avl.c`, `src/avl.h`)
* Rubro-Negra (`src/rubro_negra.c`, `src/rubro_negra.h`)

Linguagem: **C (padrão C11)**.

### 2.2 Justificativa técnica

As duas estruturas resolvem o problema de degeneração da BST simples, que pode virar uma lista encadeada quando os dados são inseridos em ordem. Mas cada uma tem um trade-off diferente:

* AVL: balanceamento estrito (fator de altura entre -1 e 1). Árvore mais baixa e buscas mais rápidas, com mais rotações em inserção/remoção
* Rubro-Negra: regras de balanceamento mais flexíveis, baseadas em cor dos nós. Menos rotações por operação de escrita, com altura um pouco maior

Escolhemos as duas pra comparar na prática o trade-off entre leitura e escrita. Os resultados estão na seção 3.5.

### 2.3 Operações implementadas

* [x] Inserção
* [x] Remoção
* [x] Busca
* [x] Percursos (pré-ordem, em ordem, pós-ordem)
* [x] Balanceamento (rotações/recoloração)
* [x] Outra: validação automática de todas as invariantes (`avl_validar` / `rn_validar`), altura, contagem de nós e métricas (rotações, recolorações, comparações e memória)

Detalhes de implementação:

* **AVL:** recursiva; cada nó guarda a própria altura. Depois de cada inserção ou remoção, o caminho até a raiz é rebalanceado com os 4 casos de rotação (Esq-Esq, Esq-Dir, Dir-Dir, Dir-Esq). Na remoção de um nó com 2 filhos, o sucessor (menor da subárvore direita) assume o lugar dele.
* **Rubro-Negra:** iterativa, no estilo do livro *Algoritmos* (Cormen et al.), com ponteiro para o pai e um **nó sentinela NIL** (preto) no lugar de todas as folhas. A correção da inserção trata 3 casos e a da remoção trata 4, cada um com a versão espelhada.

### 2.4 Complexidade

| Operação | Melhor caso | Caso médio | Pior caso |
|---|---|---|---|
| Inserção | O(log n) | O(log n) | O(log n) |
| Busca | O(1) | O(log n) | O(log n) |
| Remoção | O(log n) | O(log n) | O(log n) |
| Percursos | O(n) | O(n) | O(n) |

AVL e Rubro-Negra garantem O(log n) no pior caso por serem auto-balanceadas. Já a BST simples degenera pra O(n) no pior caso. O melhor caso da busca é O(1) quando a chave procurada está na raiz. A inserção sempre desce até uma folha, então mesmo no melhor caso custa O(log n).

Limites de altura: AVL ≤ 1,44 · log₂(n + 2) e Rubro-Negra ≤ 2 · log₂(n + 1).
Memória: O(n) nas duas (256 bytes por nó na AVL e 264 na Rubro-Negra, que guarda também o ponteiro para o pai e a cor).

---

## 3. Plano de Testes

### 3.1 Objetivo dos testes

Validar a corretude das operações (inserção, busca, remoção) e o balanceamento das árvores, e medir e comparar o desempenho (tempo, altura, rotações e memória) entre AVL e Rubro-Negra conforme o volume de dados cresce.

### 3.2 Cenários de teste

| Cenário | Entrada | Operação | Métricas registradas | Resultado esperado | Status |
|---|---|---|---|---|---|
| 1 | Inserir dataset completo em cada árvore | Inserção | Rotações e recolorações por inserção; tempo total | Todas as árvores mantêm as invariantes de balanceamento após a carga | ✅ |
| 2 | Buscas aleatórias em amostra representativa | Busca | Comparações por busca; tempo médio | Tempo médio de busca compatível com O(log n) | ✅ |
| 3 | Remoções em lote seguidas de validação de invariantes | Remoção | Rotações/recolorações por remoção; tempo total | Estrutura permanece válida (AVL: fator -1 a 1; RN: 5 regras de cor) | ✅ |

Os três cenários rodam em `testes/teste_desempenho.c`, e as invariantes foram válidas em todas as 210 execuções (7 tamanhos × 3 ordens × 2 árvores × 5 repetições).

### 3.2.1 Metodologia de execução

* **Tamanhos de entrada testados:** 1.000 / 5.000 / 10.000 / 50.000 / 100.000 / 300.000 / 500.000 registros (os 5 planejados na Entrega 1 e mais 2 intermediários, pra curva dos gráficos ficar mais precisa)
* **Condições de medição:** todos os testes rodam na mesma máquina, sem outros programas em segundo plano, pra minimizar ruído de medição
* **Aquecimento (warm-up):** a primeira execução de cada tamanho de entrada é descartada antes das 5 repetições. Em C não existe JIT, mas o aquecimento ainda reduz efeitos de cache e de alocação de memória na primeira execução
* **Repetições por teste:** cada medição roda 5 vezes com o mesmo tamanho de entrada; o resultado reportado é a média e o desvio padrão das 5 execuções
* **Busca (Cenário 2):** 10.000 buscas aleatórias por rodada, metade com chaves existentes e metade com chaves inexistentes. Aumentamos das 1.000 previstas na Entrega 1 porque, com 1.000, cada busca leva ~1 µs e o ruído da medição ficava grande demais
* **Remoção (Cenário 3):** remove-se 10% dos registros inseridos, escolhidos aleatoriamente, e as invariantes são checadas logo depois. No teste de corretude com dados reais, a remoção é feita em 10 lotes e a validação roda depois de **cada** lote
* **Mesmas chaves nas duas árvores:** as chaves de busca e de remoção são sorteadas uma única vez por tamanho e ordem, e usadas tanto na AVL quanto na Rubro-Negra (comparação justa e reproduzível)
* **Ordem de inserção:** dados em ordem aleatória (caso médio/comum), em ordem crescente e em ordem **decrescente** de chave (pior caso teórico pra uma BST simples), pra reforçar por que o balanceamento importa
* **Ferramenta de cronometragem:** `clock_gettime(CLOCK_MONOTONIC)` (resolução de nanossegundos), medindo só o tempo da operação em si, sem contar a leitura do dataset, que é carregado na memória uma vez antes de tudo

### 3.3 Casos extremos (edge cases)

| # | Caso | Comportamento esperado | Status |
|---|---|---|---|
| 1 | Árvore vazia | Busca e remoção retornam "não encontrado" sem lançar erro/exceção | ✅ |
| 2 | Único elemento | Inserção, busca (encontra) e remoção (árvore volta a ficar vazia) funcionam sem exigir rotações em nenhuma das duas árvores | ✅ |
| 3 | Dados com mesmo total_stats (e, eventualmente, mesmo nome) | Como a chave é composta (total_stats, nome, id) e id é sempre único, todos os registros entram sem colisão real, mesmo com 3+ registros de total_stats idêntico | ✅ (testado com 200 registros de mesmo total_stats e mesmo nome) |
| 4 | Inserção em ordem crescente de total_stats | Pior caso teórico para uma BST simples (degenera em lista, O(n)); AVL deve manter altura ≈ 1,44 · log₂(n) e Rubro-Negra ≤ 2 · log₂(n), evitando a degeneração | ✅ (500 mil registros: AVL altura 19, RN altura 35; limites 27 e 38) |
| 5 | Inserção em ordem decrescente de total_stats | Comportamento simétrico ao caso crescente, com as mesmas garantias de altura | ✅ (mesmas alturas do caso 4) |
| 6 | Volume máximo do dataset (~500 mil registros) | Tempo de inserção/busca cresce conforme O(log n) (não linearmente); altura final respeita os mesmos limites teóricos dos casos 4 e 5 | ✅ comparações e altura; ⚠️ tempo de relógio, ver 3.5 |
| 7 | Remover todos os elementos até a árvore ficar vazia de novo | Estado final consistente: árvore vazia, sem nós residuais, e sujeita ao comportamento do caso 1 | ✅ (validando depois de cada remoção) |

**Testes adicionais** (`testes/teste_corretude.c`):

| # | Caso | O que verifica |
|---|---|---|
| 8 | Inserir a mesma chave duas vezes | Atualiza o registro em vez de duplicar o nó |
| 9 | Percursos numa árvore conhecida | Pré-ordem, em ordem e pós-ordem saem na sequência exata esperada |
| 10 | 60.000 inserções e remoções aleatórias misturadas | Invariantes, tamanho e resultado de cada busca batem com o esperado, validando a cada 1.000 operações |
| 11 | **Sabotagem** | A árvore é corrompida de propósito (ordem, altura guardada, cor, ponteiro `pai`, tamanho) e o teste confere que o validador detecta cada erro. Prova que o validador não aprova qualquer coisa |
| 12 | 100.000 registros reais do dataset | Carga, busca de todos (conteúdo idêntico ao original), percurso em ordem estritamente crescente e remoção em 10 lotes |

**Invariantes verificadas por código**, percorrendo a árvore inteira (não só visualmente):

| | AVL (`avl_validar`) | Rubro-Negra (`rn_validar`) |
|---|---|---|
| ordem de BST, respeitando todos os ancestrais | ✔ | ✔ |
| balanceamento | fator entre -1 e 1 em todo nó | as 5 propriedades de cor |
| campos internos | altura guardada = altura real | ponteiros `pai` consistentes |
| contagem de nós = campo `tamanho` | ✔ | ✔ |

Quando uma invariante falha, o validador informa **qual** foi. Os testes também passam com AddressSanitizer (sem vazamento nem acesso inválido de memória).

### 3.4 Testes de desempenho

O tempo de execução é medido com `clock_gettime(CLOCK_MONOTONIC)` separadamente para cada fase (inserção de `n` registros, 10.000 buscas e remoção de 10%), com os tamanhos e a metodologia da seção 3.2.1. Além do tempo, cada execução registra:

* **comparações de chave** por inserção, busca e remoção (medida independente do hardware)
* **rotações** e **recolorações** (só a Rubro-Negra tem recoloração), separadas entre inserção e remoção
* **altura** da árvore depois da carga
* **memória** ocupada pelos nós: quantidade de nós × tamanho do nó (`sizeof`). Não inclui o controle interno do `malloc`, que é igual nas duas árvores

Todos os valores (média e desvio padrão das 5 repetições) ficam em `resultados/resultados_desempenho.csv`. Os gráficos são gerados a partir dele por `graficos/gerar_graficos.py`.

### 3.5 Resultados obtidos

Medido num Intel Xeon 2,8 GHz, compilado com `gcc -O2`. Os números absolutos mudam de máquina para máquina; as proporções entre as árvores se mantêm.

**Ordem aleatória (caso médio):**

| n | árvore | altura | comparações por busca | log₂(n) | inserção (µs/op) | busca (µs/op) | remoção (µs/op) | memória |
|---:|---|---:|---:|---:|---:|---:|---:|---:|
| 1.000 | AVL | 12 | 10,1 | 10,0 | 0,27 | 0,11 | 0,27 | 0,2 MB |
| 1.000 | Rubro-Negra | 12 | 10,1 | 10,0 | 0,16 | 0,11 | 0,18 | 0,3 MB |
| 10.000 | AVL | 16 | 13,1 | 13,3 | 0,46 | 0,28 | 0,58 | 2,4 MB |
| 10.000 | Rubro-Negra | 16 | 13,1 | 13,3 | 0,28 | 0,27 | 0,38 | 2,5 MB |
| 100.000 | AVL | 20 | 16,5 | 16,6 | 1,25 | 1,20 | 1,74 | 24,4 MB |
| 100.000 | Rubro-Negra | 20 | 16,5 | 16,6 | 0,92 | 1,27 | 1,56 | 25,2 MB |
| 500.000 | AVL | 23 | 18,9 | 18,9 | 1,97 | 2,03 | 2,52 | 122,1 MB |
| 500.000 | Rubro-Negra | 23 | 19,0 | 18,9 | 1,53 | 2,08 | 2,30 | 125,9 MB |

**Ordem crescente (pior caso de uma BST simples), n = 500.000:**

| árvore | altura | limite teórico | comparações por busca | inserção total | rotações por inserção |
|---|---:|---:|---:|---:|---:|
| AVL | **19** | 27 | 18,4 | 235 ms | 1,00 |
| Rubro-Negra | **35** | 38 | 18,8 | 161 ms | 1,00 |
| BST simples (teórico) | 500.000 | — | até 500.000 | — | — |

Na ordem aleatória, a AVL faz 0,75 rotação por inserção e a Rubro-Negra 0,64 (mais 2,54 recolorações).

![Comparações por busca](graficos/2_comparacoes_por_busca.png)
![Altura](graficos/3_altura.png)
![Tempo por operação](graficos/1_tempo_por_operacao.png)
![Rotações](graficos/4_rotacoes.png)

Outros gráficos: [tempo total de inserção (log-log)](graficos/5_tempo_total_insercao.png) e [memória](graficos/6_memoria.png).

**Comparação com a complexidade teórica (Big-O):**

- **As duas são O(log n) de verdade.** As comparações por busca seguem `log₂(n)` quase em cima da curva teórica, nas três ordens (veja a tabela e o gráfico de comparações). Com 500 mil registros, uma busca faz ~19 comparações; numa BST simples com inserção em ordem seriam até 500.000.
- **A AVL é mais baixa.** Na ordem crescente a AVL fica com altura 19, praticamente o mínimo possível (`log₂(n+1)` ≈ 18,9), enquanto a Rubro-Negra chega a 35. As duas respeitam os limites teóricos da seção 2.4.
- **A diferença de altura pesa pouco na busca.** Mesmo com altura 35, a busca média na Rubro-Negra custa 18,8 comparações contra 18,4 da AVL. A altura é o pior caminho; a maioria dos nós fica bem mais perto da raiz.
- **A Rubro-Negra insere mais rápido** (cerca de 20% a 30% menos tempo). Ela aceita mais desequilíbrio, então faz menos rotações na ordem aleatória, e a correção para assim que a regra de cor é satisfeita. A AVL atualiza a altura de todo o caminho até a raiz em cada inserção. Na remoção, as duas fazem praticamente o mesmo número de rotações (~0,37 por remoção).
- **Inserir em ordem é mais rápido que aleatório** nas duas árvores. Cada novo registro desce sempre pelo mesmo caminho (o mais à direita), que fica no cache da CPU.
- **O tempo de relógio cresce mais rápido que log n para n grande** (gráfico de tempo por operação). A partir de ~50 mil registros a árvore (12 MB ou mais) não cabe mais no cache da CPU, e cada nível visitado vira um acesso à memória RAM, que é bem mais lenta. O número de passos, que é o que a notação O mede, continua seguindo `log₂(n)`. Por isso o caso extremo 6 aparece com ⚠️: a complexidade está confirmada, mas o tempo real também depende da hierarquia de memória do computador.
- **Memória O(n):** cresce em linha reta com n; a Rubro-Negra usa ~3% a mais por causa do ponteiro para o pai e da cor.

**Conclusão:** para um cenário com muitas buscas e poucas alterações, a AVL é um pouco melhor (árvore mais baixa). Para muitas inserções, a Rubro-Negra é melhor (menos trabalho de rebalanceamento). Por isso ela é a usada em bibliotecas como `std::map` (C++) e `TreeMap` (Java).

---

## 4. Como Executar

### 4.1 Pré-requisitos

* **C:** compilador `gcc` com suporte a C11 (no Windows: MinGW-w64 ou MSYS2)
* **Opcional, para os gráficos:** Python 3 com `matplotlib` (`pip install matplotlib`)
* **Opcional, para regerar o dataset:** Python 3 (sem bibliotecas extras e sem internet, porque usa a `base_especies.csv` que já vem no repositório)
* `make` é opcional; sem ele, use os comandos `gcc` abaixo

### 4.2 Instruções

```
git clone <link do repositório>
cd <pasta do repositório>
```

**Com `make`** (Linux, macOS, Git Bash ou MSYS2 no Windows):
```
make testes       # testes de corretude
make desempenho   # bateria rápida (1k e 10k)
make completo     # bateria completa (1k a 500k, ~1 min) + gráficos
make graficos     # só regera os gráficos a partir do CSV
```

**Sem `make`** (PowerShell no Windows; rode na pasta raiz do projeto):
```
gcc -Wall -Wextra -O2 -std=c11 -o teste_corretude testes/teste_corretude.c src/registro.c src/avl.c src/rubro_negra.c src/dataset.c -lm
.\teste_corretude

gcc -Wall -Wextra -O2 -std=c11 -o teste_desempenho testes/teste_desempenho.c src/registro.c src/avl.c src/rubro_negra.c src/dataset.c -lm
.\teste_desempenho 1000 10000     # rápido (salva em resultados/resultados_rapido.csv)
.\teste_desempenho                # completo, 1k a 500k (salva em resultados/resultados_desempenho.csv)

python graficos/gerar_graficos.py
```

Regerar o dataset (opcional, o CSV já vem pronto):
```
python dataset/gerar_dataset.py            # 500.000 registros
python dataset/gerar_dataset.py -n 300000  # outro volume
```

### 4.3 Estrutura do repositório

```
/src          -> código-fonte
    registro.*      struct Registro + comparador da chave composta
    avl.*           árvore AVL
    rubro_negra.*   árvore Rubro-Negra
    dataset.*       leitura do CSV
/dataset      -> dataset utilizado
    base_especies.csv     1.351 espécies/variantes reais da PokéAPI
    pokemon_dataset.csv   500.000 registros
    gerar_dataset.py      gerador do dataset
/testes       -> scripts e casos de teste
    teste_corretude.c     testes automatizados das invariantes e casos extremos
    teste_desempenho.c    bateria de desempenho
/resultados   -> saídas e relatórios de desempenho
    resultados_desempenho.csv
/graficos     -> gráficos (.png) e o script que os gera
Makefile
README.md
```

---

## 5. Referências

* PokéAPI - https://pokeapi.co/
* Dados da PokéAPI em CSV - https://github.com/PokeAPI/pokeapi
* CORMEN, T. H. et al. *Algoritmos: teoria e prática*. 3. ed. Rio de Janeiro: Elsevier, 2012. (Árvore Rubro-Negra, capítulo 13)
* ADELSON-VELSKY, G. M.; LANDIS, E. M. An algorithm for the organization of information. *Soviet Mathematics Doklady*, v. 3, p. 1259–1263, 1962. (artigo original da AVL)
